package models;

import java.util.ArrayList;
import java.util.List;

public class Hotel {
	private int hotel_id ;
	private String name;
    private String Country;
    private String city;
    private String address;
    private String email ;
    private String phoneNumber;
    private List<Room> rooms;
    private List<Reservation> reservations;

    public Hotel(int hotel_id, String name, String country, String city, String address, String email, String phoneNumber) {
		this.hotel_id = hotel_id;
		this.name = name;
		Country = country;
		this.city = city;
		this.address = address;
		this.email = email;
        this.phoneNumber = phoneNumber;
        this.rooms = new ArrayList<>();
        this.reservations = new ArrayList<>();
    }
    
    public Hotel(int hotelId, String name, String country, String city, String address, String email,String phoneNumber, List<Room> rooms, List<Reservation> reservations) {
		super();
		this.hotel_id = hotel_id;
		this.name = name;
		Country = country;
		this.city = city;
		this.address = address;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.rooms = rooms;
		this.reservations = reservations;
	}

    // Méthodes pour ajouter et gérer les chambres
    public void addRoom(Room room) {
        rooms.add(room);
    }

    public List<Room> getRooms() {
        return rooms;
    }

    // Méthodes pour ajouter et gérer les réservations
    public void addReservation(Reservation reservation) {
        reservations.add(reservation);
    }

    public List<Reservation> getReservations() {
        return reservations;
    }

    // Getters et setters pour les attributs de l'hôtel
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
