package models;

import java.util.Date;

public class Reservation {
    private int rev_id;
    private Room room;
    private User guest;
    private Date check_in;
    private Date check_out;
    private Double TotPrice;

    public Reservation(int reservationId, Room room, User guest, Date checkInDate, Date checkOutDate) {
        this.rev_id = reservationId;
        this.room = room;
        this.guest = guest;
        this.check_in = checkInDate;
        this.check_out = checkOutDate;
    }

    // Getters et setters pour les attributs de la réservation
    public int getRevId() {
        return rev_id;
    }

    public void setRevId(int reservationId) {
        this.rev_id = reservationId;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public User getGuest() {
        return guest;
    }

    public void setGuest(User guest) {
        this.guest = guest;
    }

    public Date getCheckIn() {
        return check_in;
    }

    public void setCheckIn(Date checkInDate) {
        this.check_in = checkInDate;
    }

    public Date getCheckOut() {
        return check_out;
    }

    public void setCheckOut(Date checkOutDate) {
        this.check_out = checkOutDate;
    }
}

