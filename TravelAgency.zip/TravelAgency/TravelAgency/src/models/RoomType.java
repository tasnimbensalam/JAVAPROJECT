package models;

public enum RoomType {
    SINGLE, DOUBLE, SUITE, DELUXE
}

