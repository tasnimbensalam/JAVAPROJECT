package IDao;

public interface IDaoUser {

}
