package models;

public class Hotel {

}
